package com.smallorange.service.impl;

import com.smallorange.dao.UserDao;
import com.smallorange.entity.*;
import com.smallorange.service.UserService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;
    public User login(Integer schoolid, String password) {
        return userDao.findUserBySchoolIdAndPassword(schoolid,password);
    }
    public void updatePwd(String password, Integer schoolid){
        userDao.updatePwd(password,schoolid);
    }
    public List<Classes> findAllGradesBySchoolid(Integer schoolid){
        List<Classes> list=userDao.findAllGradesBySchoolid(schoolid);
        return userDao.findAllGradesBySchoolid(schoolid);
    }
    public  List<ClassesUser> findAllClassesBySchoolid(Integer schoolid){
        List<ClassesUser> list=userDao.findAllClassesBySchoolid(schoolid);
        return userDao.findAllClassesBySchoolid(schoolid);
    }
    public List<User>findAllStudentNameAndSchoolId(){
        return userDao.findAllStudentNameAndSchoolId();
    }
    public User findOneStuInfoBySchoolId(Integer schoolid){
        return userDao.findOneStuInfoBySchoolId(schoolid);
    }
    public List<ClassesUser> findOneStuClassTableBySchoolId(Integer schoolid){
        return userDao.findOneStuClassTableBySchoolId(schoolid);
    }
    public  List<Classes> findOneStuAllGradesBySchoolId(Integer schoolid){
        return userDao.findOneStuAllGradesBySchoolId(schoolid);
    }
    public List<NewClass> findOneTeacherAllNewClass(Integer schoolid){
        return userDao.findOneTeacherAllNewClass(schoolid);
    }
    public void insertNewClass(String classname,Integer classid,String classtime,String classplace, int credit,Integer teacherid,String teachername,int capacity){
        userDao.insertNewClass(classname,classid,classtime,classplace,credit,teacherid,teachername,capacity);
    }
    public List<NewClass> findAllNewClass(){
        return userDao.findAllNewClass();
    }
    public void insertNewClassToClassTable( Integer classid,String classname, Integer studentid, String classtime,String classplace, int credit, Integer teacherid,int capacity){
         userDao.insertNewClassToClassTable(classid, classname, studentid, classtime, classplace, credit, teacherid,capacity);
    }
    public Integer findClassIdByClassName(String classname){
        return userDao.findClassIdByClassName(classname);
    }
    public void insertNewClassToNewClassList(Integer classid,String classname,String classtime,String classplace,Integer teacherid,String teachername,
                                             int capacity, int stuno, int credit){
        userDao.insertNewClassToNewClassList(classid,classname,classtime,classplace,teacherid,teachername,capacity,stuno,credit);
    }
    public void insertNewClassToStuNewClass(Integer classid,String classname,String classtime,String classplace,Integer schoolid,String teachername){
        userDao.insertNewClassToStuNewClass(classid,classname,classtime,classplace,schoolid,teachername);
    }
    public List<StuNewClass> findOneStuAllNewClass(Integer schoolid){
        return userDao.findOneStuAllNewClass(schoolid);
    }
    public void updateStuno(int stuno,Integer classid){
        userDao.updateStuno(stuno,classid);
    }
    public NewClass findNewClassIsExistInNewClassTable(Integer classid){
        return userDao.findNewClassIsExistInNewClassTable(classid);
    }
    public int countSameClassid(Integer classid){
        return userDao.countSameClassid(classid);
    }
    public void updateOneStuGradesByschoolid(int grade,Integer studentid,int classid){
        userDao.updateOneStuGradesByschoolid(grade,studentid,classid);
    }
    public void adminChangeOneStuInfoBySchoolId(Integer schoolid,String name,String sex,String birthday,String place,String idnumber,String tel,String departmentname){
        userDao.adminChangeOneStuInfoBySchoolId(schoolid,name,sex,birthday,place, idnumber, tel,departmentname);
    }
    public  List<Homework> findteacherAllhomework(Integer schoolid){
        return userDao.findteacherAllhomework(schoolid);
    }
    public void teacherinsertNewHomework(String filename,String filepath,Integer uploadpersonid,String uploadpersonname,String remarks){
        userDao.teacherinsertNewHomework( filename,filepath,uploadpersonid,uploadpersonname,remarks);
    }
    public List<Homework> findAllNewHomework(){
        return userDao.findAllNewHomework();
    }
    public List<User> findAllteacher(){
        return userDao.findAllteacher();
    }
    public  int findOneTeacherEvaluationNumber(Integer schoolid){
        return userDao.findOneTeacherEvaluationNumber(schoolid);
    }
    public int findOneTeacherPleasedNumber(Integer schoolid){
        return userDao.findOneTeacherPleasedNumber(schoolid);
    }
    public void updateOneTeacherEvanoAndPleNo(int evaluationnumber,int pleasednumber,Integer schoolid){
        userDao.updateOneTeacherEvanoAndPleNo(evaluationnumber,pleasednumber,schoolid);
    }
    public void insertStudentMessage(Integer schoolid,String word){
        userDao.insertStudentMessage(schoolid,word);
    }
    public  List<Message> teacherFindSatisfactionDegree(Integer schoolid){
        return userDao.teacherFindSatisfactionDegree(schoolid);
    }


    public String getUser(User user){
        if ((user != null) && (user.getType() == 0)) {
            return "admin";
        } else if ((user != null) && (user.getType() == 1)) {
            return "teacher";
        } else if ((user != null) && (user.getType() == 2)) {
            return "student";
        }
        return "login";
    }

    public int getList(List<NewClass> list,Integer classid){
        int i;
        for (i = 0; i < list.size(); i++) {
            if (list.get(i).getClassid() == classid) {
                break;
            }
        }
        return i;
    }

    public int getList2(List<Homework> list,Integer id){
        int i;
        for( i=0;i<list.size();i++){
            if(list.get(i).getId()==id) break;
        }
        return i;
    }

    //admin
    public List<User> adminCheckUser(){
        return userDao.adminCheckUser();
    }
    public void   admindelectUser(Integer schoolid){
        userDao.admindelectUser(schoolid);
    }
    public User adminFindOneUser(@Param("schoolid") Integer schoolid){
        return userDao.adminFindOneUser(schoolid);
    }
    public  void  adminUpdateUser( @Param("schoolid")Integer schoolid,@Param("password")String password, @Param("name")String name,@Param("sex") String sex, @Param("birthday")String birthday,@Param("place") String place, @Param("tel")String tel, @Param("idnumber")String idnumber,@Param("type") int type,@Param("departmentname") String departmentname){
        userDao.adminUpdateUser( schoolid, password,name,  sex,  birthday,  place,  tel,  idnumber,  type,  departmentname);

    }
    public  void  adminInsertUser( @Param("schoolid")Integer schoolid,@Param("password")String password, @Param("name")String name,@Param("sex") String sex, @Param("birthday")String birthday,@Param("place") String place, @Param("tel")String tel, @Param("idnumber")String idnumber,@Param("type") int type,@Param("departmentname") String departmentname){
        userDao.adminInsertUser( schoolid, password,name,  sex,  birthday,  place,  tel,  idnumber,  type,  departmentname);
    }
}
