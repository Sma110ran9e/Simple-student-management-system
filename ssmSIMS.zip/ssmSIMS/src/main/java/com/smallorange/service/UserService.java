package com.smallorange.service;

import com.smallorange.entity.*;



import java.util.List;

public interface UserService {
    User login(Integer schoolid,String password);
    void updatePwd(String password,Integer schoolid);
    List<Classes> findAllGradesBySchoolid(Integer schoolid);
    List<ClassesUser> findAllClassesBySchoolid(Integer schoolid);
    List<User>findAllStudentNameAndSchoolId();
    User findOneStuInfoBySchoolId(Integer schoolid);
    List<ClassesUser> findOneStuClassTableBySchoolId(Integer schoolid);
    List<Classes> findOneStuAllGradesBySchoolId(Integer schoolid);
    void insertNewClass(String classname,Integer classid,String classtime,String classplace, int credit,Integer teacherid,String teachername,int capacity);
    List<NewClass> findOneTeacherAllNewClass(Integer schoolid);
    List<NewClass> findAllNewClass();
    void insertNewClassToClassTable( Integer classid,String classname, Integer studentid,
                                  String classtime,String classplace, int credit,
                                    Integer teacherid,int capacity);
    Integer findClassIdByClassName(String classname);
    void insertNewClassToNewClassList(Integer classid,String classname,String classtime,String classplace,Integer teacherid,String teachername,
                                      int capacity, int stuno, int credit);
    void insertNewClassToStuNewClass(Integer classid,String classname,String classtime,String classplace,Integer schoolid,String teachername);
    List<StuNewClass> findOneStuAllNewClass( Integer schoolid);
    void updateStuno(int stuno,Integer classid);
    NewClass findNewClassIsExistInNewClassTable(Integer classid);
    int countSameClassid(Integer classid);
    void updateOneStuGradesByschoolid(int grade,Integer studentid,int classid);
    void adminChangeOneStuInfoBySchoolId(Integer schoolid,String name,String sex,String birthday,String place,String idnumber,String tel,String departmentname);
    List<Homework> findteacherAllhomework(Integer schoolid);
    void teacherinsertNewHomework(String filename,String filepath,Integer uploadpersonid,String uploadpersonname,String remarks);
    List<Homework> findAllNewHomework();
    List<User> findAllteacher();
    int findOneTeacherEvaluationNumber(Integer schoolid);
    int findOneTeacherPleasedNumber(Integer schoolid);
    void updateOneTeacherEvanoAndPleNo(int evaluationnumber,int pleasednumber,Integer schoolid);
    void insertStudentMessage(Integer schoolid,String word);
    List<Message> teacherFindSatisfactionDegree(Integer schoolid);
    String getUser(User usser);
    int getList(List<NewClass> list,Integer classid);
    int getList2(List<Homework> list,Integer id);
    //admin
    List<User> adminCheckUser();
    void   admindelectUser(Integer schoolid);
    User adminFindOneUser( Integer schoolid);
    void adminUpdateUser( Integer schoolid,String password, String name, String sex, String birthday, String place, String tel,String idnumber, int type,String departmentname);
    void   adminInsertUser (Integer schoolid,String password,String name,String sex,String birthday,String place, String tel,String idnumber, int type, String departmentname);

}
