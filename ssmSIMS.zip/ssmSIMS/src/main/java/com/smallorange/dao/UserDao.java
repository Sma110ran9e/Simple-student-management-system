package com.smallorange.dao;

import com.smallorange.entity.*;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UserDao {
    @Select("select schoolid ,password,type,name from user where schoolid=#{schoolid} and password=#{password}")
    User findUserBySchoolIdAndPassword(@Param("schoolid") Integer schoolid, @Param("password")String password);

    @Update("update user set password=#{password} where schoolid=#{schoolid}")
    void updatePwd(@Param("password") String password,@Param("schoolid") Integer schoolid);

    @Select("select c.classname, c.classid, c.grade from user u ,classes c where u.schoolid=#{schoolid} and c.studentid=u.schoolid")
    List<Classes> findAllGradesBySchoolid(@Param("schoolid")Integer schoolid);

    @Select("select c.classname, c.classid, c.classtime, c.classplace, c.credit,u1.name as studentname, u2.name as teachername from  classes c " +
            "left join user as u1 on c.studentid=u1.schoolid " +
            "left join user as u2 on c.teacherid=u2.schoolid " +
            "where u1.schoolid=#{schoolid}")
    List<ClassesUser> findAllClassesBySchoolid(@Param("schoolid")Integer schoolid);

    @Select("select name, schoolid from user where type=2")
    List<User>findAllStudentNameAndSchoolId();

    @Select("select name, schoolid, sex, birthday,place,idnumber,tel,departmentname from user where schoolid=#{schoolid}")
    User findOneStuInfoBySchoolId(Integer schoolid);

    @Select("select classname, classid, classtime, classplace from classes  where studentid=#{schoolid}")
    List<ClassesUser> findOneStuClassTableBySchoolId(@Param("schoolid")Integer schoolid);

    @Select("select classname, classid, studentid,grade from classes where studentid=#{schoolid}")
    List<Classes> findOneStuAllGradesBySchoolId(@Param("schoolid")Integer schoolid);

    @Insert("insert into newclass (classname,classid,classtime,classplace,credit,teacherid,teachername,capacity) values(#{classname},#{classid},#{classtime},#{classplace},#{credit},#{teacherid},#{teachername},#{capacity})")
    void insertNewClass(@Param("classname")String classname,@Param("classid")Integer classid,@Param("classtime")String classtime,@Param("classplace")String classplace, @Param("credit")int credit,@Param("teacherid")Integer teacherid,@Param("teachername")String teachername,@Param("capacity")int capacity);

    @Select("select * from newclass where teacherid=#{schoolid}")
    List<NewClass> findOneTeacherAllNewClass(@Param("schoolid")Integer schoolid);

    @Select("select * from newclass")
    List<NewClass> findAllNewClass();

    @Insert("insert into classes (classid,classname,studentid,classtime,classplace,credit,teacherid,capacity) " +
            "values(#{classid},#{classname},#{studentid},#{classtime},#{classplace},#{credit},#{teacherid},#{capacity})")
    void insertNewClassToClassTable(@Param("classid") Integer classid,@Param("classname")String classname,@Param("studentid") Integer studentid,
                                    @Param("classtime")String classtime,@Param("classplace")String classplace, @Param("credit")int credit,
                                    @Param("teacherid")Integer teacherid,@Param("capacity")int capacity);

    @Select("select classid from newclass where classname=#{classname}")
    Integer findClassIdByClassName(@Param("classname")String classname);

    @Insert("insert into newclass (classid,classname,classtime,classplace,teacherid,teachername,capacity,stuno,credit)" +
                         "values(#{classid},#{classname},#{classtime},#{classplace},#{teacherid},#{teachername},#{capacity},#{stuno},#{credit})")
    void insertNewClassToNewClassList(@Param("classid")Integer classid,@Param("classname")String classname,@Param("classtime")
            String classtime,@Param("classplace")String classplace,@Param("teacherid")Integer teacherid, @Param("teachername") String teachername,
                                      @Param("capacity") int capacity,@Param("stuno") int stuno,@Param("credit") int credit);

    @Insert("insert into stunewclass (classid,classname,classtime,classplace,schoolid,teachername)" +
            "values(#{classid},#{classname},#{classtime},#{classplace},#{schoolid},#{teachername})")
    void insertNewClassToStuNewClass(@Param("classid")Integer classid,@Param("classname")String classname,@Param("classtime")
            String classtime,@Param("classplace")String classplace,@Param("schoolid")Integer schoolid, @Param("teachername") String teachername);

    @Select("select classname,classid,classtime,classplace,teachername from stunewclass where schoolid=#{schoolid}")
    List<StuNewClass> findOneStuAllNewClass(@Param("schoolid") Integer schoolid);

    @Update("update newclass set stuno=#{stuno} where classid=#{classid}")
    void updateStuno(@Param("stuno")int stuno,@Param("classid") Integer classid);

    @Select("select * from newclass where classid=#{classid}")
    NewClass findNewClassIsExistInNewClassTable(@Param("classid") Integer classid);

    @Select("select sum(classid=#{classid}) from stunewclass")
    int countSameClassid(@Param("classid") Integer classid);

    @Update("update classes set grade=#{grade} where studentid=#{studentid} and classid=#{classid}")
    void updateOneStuGradesByschoolid(@Param("grade") int grade,@Param("studentid") Integer studentid,@Param("classid") int classid);

    @Update("update user set name=#{name},sex=#{sex},birthday=#{birthday},place=#{place},idnumber=#{idnumber},tel=#{tel}," +
            "departmentname=#{departmentname},picture=#{picture},picturepath=#{picturepath} where schoolid=#{schoolid}")
    void adminChangeOneStuInfoBySchoolId(@Param("schoolid") Integer schoolid,@Param("name")String name,@Param("sex")String sex,
                                         @Param("birthday") String birthday,@Param("place")String place,@Param("idnumber")String idnumber,
                                         @Param("tel")String tel,@Param("departmentname")String departmentname);

    @Select("select * from homework where uploadpersonid=#{schoolid}")
    List<Homework> findteacherAllhomework(@Param("schoolid") Integer schoolid);

    @Insert("insert into homework (filename,filepath,uploadpersonid,uploadpersonname,remarks,type) values(#{filename},#{filepath},#{uploadpersonid},#{uploadpersonname},#{remarks},1)")
    void teacherinsertNewHomework(@Param("filename")String filename,@Param("filepath")String filepath,@Param("uploadpersonid")Integer uploadpersonid,
                                  @Param("uploadpersonname")String uploadpersonname,@Param("remarks")String remarks);

    @Select("select * from homework")
    List<Homework> findAllNewHomework();

    @Select("select * from user where type=1")
    List<User> findAllteacher();

    @Select("select evaluationnumber from user where schoolid=#{schoolid} and type=1")
    int findOneTeacherEvaluationNumber(@Param("schoolid")Integer schoolid);

    @Select("select pleasednumber from user where schoolid=#{schoolid} and type=1")
    int findOneTeacherPleasedNumber(@Param("schoolid")Integer schoolid);

    @Update("update user set evaluationnumber=#{evaluationnumber},pleasednumber=#{pleasednumber} where schoolid=#{schoolid}")
    void updateOneTeacherEvanoAndPleNo(@Param("evaluationnumber")int evaluationnumber,@Param("pleasednumber")int pleasednumber,@Param("schoolid")Integer schoolid);

    @Insert("insert into messages (id,word) values(#{schoolid},#{word})")
    void insertStudentMessage(@Param("schoolid")Integer schoolid,@Param("word")String word);

    @Select("select * from messages where id=#{schoolid}")
    List<Message> teacherFindSatisfactionDegree(@Param("schoolid") Integer schoolid);

    //admin
    @Select("select * from user ")
    List<User> adminCheckUser();

    @Select("select * from user where schoolid=#{schoolid}")
    User adminFindOneUser(@Param("schoolid") Integer schoolid);

    @Select("delete from user where schoolid=#{schoolid}")
    void admindelectUser(@Param("schoolid") Integer schoolid);

    @Select("update user set password=#{password},name=#{name},sex=#{sex},birthday=#{birthday},place=#{place},tel=#{tel},idnumber=#{idnumber},type=#{type},departmentname=#{departmentname} where schoolid=#{schoolid}")
    void adminUpdateUser(@Param("schoolid") Integer schoolid,@Param("password") String password,@Param("name") String name,@Param("sex") String sex,@Param("birthday") String birthday,@Param("place") String place,@Param("tel") String tel,@Param("idnumber") String idnumber,@Param("type") int type,@Param("departmentname") String departmentname);

    @Select("insert into user (schoolid,password,name,sex,birthday,place,tel,idnumber,type,departmentname ) VALUES (#{schoolid} ,#{password},#{name},#{sex},#{birthday},#{place},#{tel},#{idnumber},#{type},#{departmentname} )")
    void adminInsertUser(@Param("schoolid") Integer schoolid,@Param("password") String password,@Param("name") String name,@Param("sex") String sex,@Param("birthday") String birthday,@Param("place") String place,@Param("tel") String tel,@Param("idnumber") String idnumber,@Param("type") int type,@Param("departmentname") String departmentname);

}
