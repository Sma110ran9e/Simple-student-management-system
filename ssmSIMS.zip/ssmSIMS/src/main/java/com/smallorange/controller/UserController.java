package com.smallorange.controller;

import com.smallorange.entity.*;
import com.smallorange.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.math.BigDecimal;
import java.util.List;


@Controller
@Transactional
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;


    @RequestMapping("/login")
    //跳转到登录页面
    public String login() {
        return "login";
    }


    @RequestMapping("/checklogin")
    //验证用户名，密码是否正确，正确则跳转至对应的jsp
    public String checkLogin(Integer schoolid, String password, HttpSession session, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = userService.login(schoolid, password);
        session.setAttribute("user",user);
        return  userService.getUser(user);
    }


    @RequestMapping("changepwd")
    public String changepwd(){
        return "changepwd";
    }

    @RequestMapping("checkpwd")
    public String changgepwd(HttpSession session, @RequestParam String pwd1, @RequestParam String pwd2){
        User user=(User)session.getAttribute("user");
        System.out.println(pwd1+" "+user.getSchoolid());
        if(pwd1.equals(pwd2)){
            userService.updatePwd(pwd1,user.getSchoolid());
        }
        return "login";
    }
    @RequestMapping("/outLogin")
    //退出当前用户，返回到登录页面，销毁session
    public ModelAndView outLogin(HttpSession session) {
        session.invalidate();
        return new ModelAndView( "redirect:/user/login");
    }


    @RequestMapping("findAllGrades")
    //查询该学生的所有课程成绩
    public String findAllGradesBySchoolid(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        Integer id = user.getSchoolid();
        List<Classes> list = userService.findAllGradesBySchoolid(id);
        model.addAttribute("list", list);
        return "studentfindgrades";
    }


    @RequestMapping("findAllClasses")
    //查询该学生的所有课程信息
    public String findAllClassesBySchoolid(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        Integer id = user.getSchoolid();
        List<ClassesUser> list = userService.findAllClassesBySchoolid(id);
        model.addAttribute("list", list);
        return "studentfindclasstable";
    }


    @RequestMapping("findAllStudentNameAndSchoolId")
    //查询学生的学号和姓名，便于后期操作
    public String findAllStudentNameAndId(Model model) {
        List<User> list = userService.findAllStudentNameAndSchoolId();
        model.addAttribute("list", list);
        return "teacherfindstuinfo";
    }


    @RequestMapping(value = "findOneStuInfoBySchoolId/{schoolid}")
    //根据学生学号查询学生基本信息
    public String findOneStuInfoBySchoolId(HttpSession session, @PathVariable Integer schoolid) {

        User user1 = userService.findOneStuInfoBySchoolId(schoolid);
        session.setAttribute("user1", user1);
        return "teacherfindstuinfo-base";
    }


    @RequestMapping(value = "findOneStuClassTableBySchoolid/{schoolid}")
    //根据学生学号查询该生课表
    public String findOneStuClassTableBySchoolid(HttpSession session, @PathVariable Integer schoolid) {
        List<ClassesUser> list = userService.findOneStuClassTableBySchoolId(schoolid);
        session.setAttribute("list", list);
        return "teacherfindstuinfo-classtable";
    }


    @RequestMapping(value = "findOneStuAllGradesBySchoolId/{schoolid}")
    //根据学生学号查询该生所有课程成绩
    public String findOneStuAllGradesBySchoolId(HttpSession session, @PathVariable Integer schoolid) {
        List<Classes> list = userService.findOneStuAllGradesBySchoolId(schoolid);
        session.setAttribute("list", list);
        return "teacherfindstuinfo-grades";
    }


    @RequestMapping("insertNewClass")
    //点击超链接跳转到老师开设课程页面，并查询目前该老师已经开设的所有课程
    public String insertNewClass(HttpServletRequest request, HttpSession session) {
        User user = (User) session.getAttribute("user");
        List<NewClass> list = userService.findOneTeacherAllNewClass(user.getSchoolid());
        request.setAttribute("list", list);
        return "teacherinsertnewclass";
    }


    @RequestMapping("findOneTeacherAllNewClass")
    //插入老师开设的课程后再次查询目前该老师已经开设的所有课程，并在当前页面展示
    public String findOneTeacherAllNewClass(String classname, String classtime, String classplace, int credit, int capacity, HttpServletRequest request, HttpSession session) {
        User user = (User) session.getAttribute("user");
        Integer schoolid = user.getSchoolid();
        String name = user.getName();
        Integer classid = userService.findClassIdByClassName(classname);
        userService.insertNewClass(classname, classid, classtime, classplace, credit, schoolid, name, capacity);
        List<NewClass> list = userService.findOneTeacherAllNewClass(user.getSchoolid());
        session.setAttribute("list", list);
        return "teacherinsertnewclass";
    }


    @RequestMapping("chooseNewClass")
    //跳转到选课页面
    public String chooseNewClass(HttpSession session, HttpServletRequest request) {
        User user = (User) session.getAttribute("user");
        List<NewClass> list = userService.findAllNewClass();
        session.setAttribute("list", list);
        List<StuNewClass> list2 = userService.findOneStuAllNewClass(user.getSchoolid());
        request.setAttribute("list2", list2);
        return "studentchooseclasses";
    }


    @RequestMapping("findOneStudentAllClass/{classid}")
    //选课成功后将选的课程显示在本页，同时刷新已选人数和更新学生课表
    public ModelAndView findOneStudentAllClass(HttpSession session, HttpServletRequest request, HttpServletResponse response, @PathVariable Integer classid) throws IOException {
        User user = (User) session.getAttribute("user");
        List<NewClass> list = (List<NewClass>) session.getAttribute("list");
        int i=userService.getList(list,classid);
        NewClass newClass = userService.findNewClassIsExistInNewClassTable(classid);
        if (newClass == null) {
            userService.insertNewClassToNewClassList(classid, list.get(i).getClassname(), list.get(i).getClasstime(), list.get(i).getClassplace(), list.get(i).getTeacherid(), list.get(i).getTeachername(), list.get(i).getCapacity(), list.get(i).getStuno(), list.get(i).getCredit());
        }
        userService.insertNewClassToStuNewClass(classid, list.get(i).getClassname(), list.get(i).getClasstime(), list.get(i).getClassplace(), user.getSchoolid(), list.get(i).getTeachername());
        userService.insertNewClassToClassTable(classid, list.get(i).getClassname(), user.getSchoolid(), list.get(i).getClasstime(), list.get(i).getClassplace(), list.get(i).getCredit(), list.get(i).getTeacherid(), list.get(i).getStuno());
        int k = userService.countSameClassid(classid);
        userService.updateStuno(k, classid);
        List<StuNewClass> list2 = userService.findOneStuAllNewClass(user.getSchoolid());
        request.setAttribute("list2", list2);
        return new ModelAndView("redirect:/user/chooseNewClass");
    }


    @RequestMapping("findAllStudentNameAndSchoolId2")
    //显示所有学生的姓名和学号
    public String findAllStudentNameAndId2(Model model) {
        List<User> list = userService.findAllStudentNameAndSchoolId();
        model.addAttribute("list", list);
        return "teacherfindstuinfo2";
    }


    @RequestMapping(value = "findOneStuAllGradesBySchoolId2/{studentid}")
    //根据学生学号查询该生所有课程成绩
    public String findOneStuAllGradesBySchoolId2(HttpSession session, @PathVariable Integer studentid) {
        List<Classes> list = userService.findOneStuAllGradesBySchoolId(studentid);
        session.setAttribute("list", list);
        return "teacherfindstuinfo-grades2";
    }


    @RequestMapping("updateOneStuOneGradesBySchoolidAndClassid/{studentid}/{classid}")
    //修改成绩，然后重定向到上一个方法
    public ModelAndView  updateOneStuOneGradesBySchoolidAndClassid(HttpSession session,@PathVariable  Integer studentid,@PathVariable  int classid,int grade){
        userService.updateOneStuGradesByschoolid(grade,studentid,classid);
        return new ModelAndView("redirect:/user/findOneStuAllGradesBySchoolId2/{studentid}");
    }




    @RequestMapping("findteacherAllhomework")
    //查询该老师所有布置的作业
    public String findteacherAllhomework(HttpSession session){
        User user = (User) session.getAttribute("user");
        List<Homework> list=userService.findteacherAllhomework(user.getSchoolid());
        session.setAttribute("homeworklist",list);
        return "teacherinsertnewhomework";
    }


    @RequestMapping(value = "insertNewHomework",method = RequestMethod.GET)
    public String insertNewHomework1(HttpSession session){
        User user = (User) session.getAttribute("user");
        List<Homework> list=userService.findteacherAllhomework(user.getSchoolid());
        session.setAttribute("homeworklist",list);
        return "teacherinsertnewhomework";
    }


    @RequestMapping(value = "insertNewHomework",method = RequestMethod.POST)
    //老师上传作业
    public ModelAndView insertNewHomework(HttpSession session, HttpServletRequest request,String remarks) throws IOException{
        User user = (User) session.getAttribute("user");
        MultipartHttpServletRequest multipartHttpServletRequest=(MultipartHttpServletRequest) request;
        MultipartFile file=multipartHttpServletRequest.getFile("myfile");
        String fname=file.getOriginalFilename();
        String filepath="C:\\Users\\SAMSUNG\\Desktop\\homework";
        String newfilepath=filepath+"\\"+fname;
        newfilepath=new String(newfilepath.getBytes("utf-8"),"iso-8859-1");
        File newfile=new File(newfilepath);
        file.transferTo(newfile);
        userService.teacherinsertNewHomework(fname,newfilepath,user.getSchoolid(),user.getName(),remarks);
        return new ModelAndView("redirect:/user/findteacherAllhomework");
    }


    @RequestMapping("findAllNewHomework")
    //学生查询所有老师布置的作业
    public String findAllNewHomework(HttpSession session){
        List<Homework>list=userService.findAllNewHomework();
        session.setAttribute("allnewhomework",list);
        return "studentfindallnewhomework";
    }


    @RequestMapping("studentdownloadhomework/{id}")
    public void studentdownloadhomework(HttpServletResponse response,HttpSession session,@PathVariable int id) throws IOException {
        List<Homework>list=(List<Homework>)session.getAttribute("allnewhomework");
        int i=userService.getList2(list,id);
        String path=list.get(i).getFilepath();
        File file=new File(path);
        String filename=new String(file.getPath().getBytes("utf-8"),"iso-8859-1");
        System.out.println(filename);
        InputStream bis = new BufferedInputStream(new FileInputStream(new File(filename)));
        response.addHeader("Content-Disposition","attachment;filename="+filename);
        //1.设置文件ContentType类型，这样设置，会自动判断下载文件类型    
        response.setContentType("multipart/form-data");
        BufferedOutputStream out=new BufferedOutputStream(response.getOutputStream());
        int len=0;
        while((len=bis.read())!=-1) {
            out.write(len);
            out.flush();
        }
        out.close();
    }



    @RequestMapping("findAllTeacher")
    //学生进入评价系统，先查询所有教师
    public String findAllTeacher(HttpSession session){
        List<User> teacherlist=userService.findAllteacher();
        session.setAttribute("teacherlist",teacherlist);
        return "studentevaluateteacher";
    }


    @RequestMapping("evaluateOneTeacher/{schoolid}")
    //跳转到某位老师的评价页面
    public String evaluateOneTeacher(@PathVariable Integer schoolid,HttpSession session ){
        session.setAttribute("schoolid",schoolid);
        return "studentevaluatedetail";
    }


    @RequestMapping("evaluateDetail/{schoolid}")
    //评价详情：若jsp点击“满意”，则评价总人数和满意人数各加一，否则只加总人数，评价完成后返回
    public String evaluateDetail(HttpSession session,@PathVariable Integer schoolid,String pingjia,String word){
        int evaluationnumber=userService.findOneTeacherEvaluationNumber(schoolid);                                      //参与评价总人数
        int pleasednumber=userService.findOneTeacherPleasedNumber(schoolid);                                            //评价为“满意”的人数
        if(pingjia.equals("满意")){
            evaluationnumber++;
            pleasednumber++;
        }
        else evaluationnumber++;
        userService.updateOneTeacherEvanoAndPleNo(evaluationnumber,pleasednumber,schoolid);
        userService.insertStudentMessage(schoolid,word);
        return "studentevaluateteacher";
    }


    @RequestMapping("teacherfindsatisfactiondegree")
    //教师页面显示学生评教的数据
    public String teacherFindSatisfactionDegree(HttpSession session){
        User user=(User)session.getAttribute("user");
        double satisfactiondegree;
        int evaluationnumber=userService.findOneTeacherEvaluationNumber(user.getSchoolid());
        int pleasednumber=userService.findOneTeacherPleasedNumber(user.getSchoolid());
        if(evaluationnumber==0)  {satisfactiondegree=0;}
        else satisfactiondegree = new BigDecimal((float)pleasednumber/evaluationnumber).setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue()*100;//满意度，乘100是因为该数据在jsp页面用百分数表示
        session.setAttribute("satisfactiondegree",satisfactiondegree);
        session.setAttribute("evaluationnumber",evaluationnumber);
        List<Message> messages=userService.teacherFindSatisfactionDegree(user.getSchoolid());
        session.setAttribute("messages",messages);
        return "teachersatisfactiondegree";
    }


    //admin
    @RequestMapping("adminCheckUser")
    public String  adminCheckUser(Model model) {
        List<User> list = userService.adminCheckUser();
        model.addAttribute("list", list);
        return "adminCheckUser";
    }
    @RequestMapping("adminCheckUserBeforeDelect")
    public String  adminCheckUserBeforeDelect(Model model) {
        List<User> list = userService.adminCheckUser();
        model.addAttribute("list", list);
        return "admindelectUser";
    }

    @RequestMapping(value="admindelectUser/{schoolid}")
    public ModelAndView admindelectUser(Model model,@PathVariable Integer schoolid) {
        userService.admindelectUser(schoolid);
        return new ModelAndView("redirect:/user/adminCheckUserBeforeDelect");
    }
    @RequestMapping("adminCheckUserBeforeUpdate")
    public String  adminCheckUserBeforeUpdate(HttpSession session,Model model) {
        List<User> list = userService.adminCheckUser();
        model.addAttribute("list", list);
        session.setAttribute("list", list);
        return "adminupdateUser";
    }
    @RequestMapping(value="/adminUpdateUser")
    public ModelAndView adminUpdateUser( Integer schoolid, HttpSession session, String password, String name,  String sex,  String birthday, String place,  String tel, String idnumber, String type,  String departmentname,HttpServletRequest request){
        Integer schoolid2 = null;
        if(schoolid!=null){
            schoolid2 = Integer.valueOf(schoolid);
        }
        int type2 =Integer.parseInt(type);
        userService.adminUpdateUser(schoolid2,password,name,sex,birthday,place,tel,idnumber,type2,departmentname);
        User user2=userService.adminFindOneUser(schoolid);
        session.setAttribute("user2",user2);
        return new ModelAndView("redirect:/user/adminCheckUserBeforeUpdate");
    }

    @RequestMapping("adminUpdateUser/{schoolid}")
    public String adminUpdateUser2(@PathVariable Integer schoolid, HttpSession session){
        User user2=userService.adminFindOneUser(schoolid);
        session.setAttribute("user2",user2);
        return "adminupdateUser";
    }

    @RequestMapping("/adminCheckUserBeforeInsert")
    public String  adminCheckUserBeforeInsert(HttpSession session,Model model) {
        List<User> list = userService.adminCheckUser();
        model.addAttribute("list", list);
        session.setAttribute("list", list);
        return "admininsertUser";
    }
    @RequestMapping(value="/adminInsertUser")
    public ModelAndView adminInsertUser( String schoolid,  String password, String name,  String sex,  String birthday, String place,  String tel, String idnumber, String type,  String departmentname){
        Integer schoolid2 = null;
        if(schoolid!=null){
            schoolid2 = Integer.valueOf(schoolid);
        }
        int type2 =Integer.parseInt(type);
        userService.adminInsertUser(schoolid2,password,name,sex,birthday,place,tel,idnumber,type2,departmentname);
        System.out.println(schoolid2+password+type2);
        return new ModelAndView("redirect:/user/adminCheckUserBeforeInsert");
    }
}