package com.smallorange.entity;

import java.io.Serializable;

public class NewClass implements Serializable {
    private int classid;
    private String classname;
    private Integer teacherid;
    private String teachername;
    private int stuno;
    private int capacity;
    private String classtime;
    private String classplace;
    private int credit;

    public int getClassid() {
        return classid;
    }

    public void setClassid(int classid) {
        this.classid = classid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Integer getTeacherid() {
        return teacherid;
    }

    public void setTeacherid(Integer teacherid) {
        this.teacherid = teacherid;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public int getStuno() {
        return stuno;
    }

    public void setStuno(int stuno) {
        this.stuno = stuno;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getClasstime() {
        return classtime;
    }

    public void setClasstime(String classtime) {
        this.classtime = classtime;
    }

    public String getClassplace() {
        return classplace;
    }

    public void setClassplace(String classplace) {
        this.classplace = classplace;
    }

    public int getCredit() {
        return credit;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }

    @Override
    public String toString() {
        return "NewClass{" +
                "classid=" + classid +
                ", classname='" + classname + '\'' +
                ", teacherid=" + teacherid +
                ", teachername='" + teachername + '\'' +
                ", stuno=" + stuno +
                ", capacity=" + capacity +
                ", classtime='" + classtime + '\'' +
                ", classplace='" + classplace + '\'' +
                ", credit=" + credit +
                '}';
    }
}