package com.smallorange.entity;

public class StuNewClass extends NewClass  {
    private Integer schoolid;

    public Integer getSchoolid() {
        return schoolid;
    }

    public void setSchoolid(Integer schoolid) {
        this.schoolid = schoolid;
    }

}
