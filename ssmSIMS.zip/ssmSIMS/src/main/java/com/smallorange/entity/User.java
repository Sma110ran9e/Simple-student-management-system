package com.smallorange.entity;

import java.io.Serializable;

public class User implements Serializable {
    private Integer schoolid;
    private String password;
    private String name;
    private String sex;
    private String birthday;
    private String place;
    private String tel;
    private String idnumber;
    private int type;
    private String departmentname;
    private int evaluationnumber;

    public int getEvaluationnumber() {
        return evaluationnumber;
    }

    public void setEvaluationnumber(int evaluationnumber) {
        this.evaluationnumber = evaluationnumber;
    }

    public int getPleasednumber() {
        return pleasednumber;
    }

    public void setPleasednumber(int pleasednumber) {
        this.pleasednumber = pleasednumber;
    }

    private int pleasednumber;

    public Integer getSchoolid() {
        return schoolid;
    }

    public void setSchoolid(Integer schoolid) {
        this.schoolid = schoolid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(String idnumber) {
        this.idnumber = idnumber;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDepartmentname() {
        return departmentname;
    }

    public void setDepartmentname(String departmentname) {
        this.departmentname = departmentname;
    }

    @Override
    public String toString() {
        return "User{" +
                "schoolid=" + schoolid +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", birthday='" + birthday + '\'' +
                ", place='" + place + '\'' +
                ", tel='" + tel + '\'' +
                ", idnumber='" + idnumber + '\'' +
                ", type=" + type +
                ", departmentname='" + departmentname + '\'' +
                ", evaluationnumber=" + evaluationnumber +
                ", pleasednumber=" + pleasednumber +
                '}';
    }
}