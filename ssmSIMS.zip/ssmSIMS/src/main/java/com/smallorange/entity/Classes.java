package com.smallorange.entity;

import java.io.Serializable;

public class Classes implements Serializable{
    private int classid;
    private String classname;
    private Integer studentid;
    private int grade;
    private Integer teacherid;
    private int stuno;
    private int capacity;
    private String classtime;
    private String classplace;
    private int credit;

    @Override
    public String toString() {
        return "Classes{" +
                "classid=" + classid +
                ", classname='" + classname + '\'' +
                ", studentid=" + studentid +
                ", grade=" + grade +
                ", teacherid=" + teacherid +
                ", stuno=" + stuno +
                ", capacity=" + capacity +
                ", classtime='" + classtime + '\'' +
                ", classplace='" + classplace + '\'' +
                ", credit=" + credit +
                '}';
    }

    public int getCredit() {
        return credit;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }

    public String getClasstime() {
        return classtime;
    }

    public void setClasstime(String classtime) {
        this.classtime = classtime;
    }

    public String getClassplace() {
        return classplace;
    }

    public void setClassplace(String classplace) {
        this.classplace = classplace;
    }



    public int getClassid() {
        return classid;
    }

    public void setClassid(int classid) {
        this.classid = classid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Integer getStudentid() {
        return studentid;
    }

    public void setStudentid(Integer studentid) {
        this.studentid = studentid;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public Integer getTeacherid() {
        return teacherid;
    }

    public void setTeacherid(Integer teacherid) {
        this.teacherid = teacherid;
    }

    public int getStuno() {
        return stuno;
    }

    public void setStuno(int stuno) {
        this.stuno = stuno;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

}