package com.smallorange.entity;

import java.io.Serializable;

public class ClassesUser extends Classes implements Serializable {
    private String teachername;
    private String studentname;

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public String getStudentname() {
        return studentname;
    }

    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }
}