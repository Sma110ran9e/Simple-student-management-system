package com.smallorange.entity;

import java.io.Serializable;

public class Homework implements Serializable {
    private int id;
    private String filename;
    private String filepath;
    private String uploadpersonid;
    private String uploadpersonname;
    private String remarks;
    private int type;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getUploadpersonid() {
        return uploadpersonid;
    }

    public void setUploadpersonid(String uploadpersonid) {
        this.uploadpersonid = uploadpersonid;
    }

    public String getUploadpersonname() {
        return uploadpersonname;
    }

    public void setUploadpersonname(String uploadpersonname) {
        this.uploadpersonname = uploadpersonname;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Homework{" +
                "id=" + id +
                ", filename='" + filename + '\'' +
                ", filepath='" + filepath + '\'' +
                ", uploadpersonid='" + uploadpersonid + '\'' +
                ", uploadpersonname='" + uploadpersonname + '\'' +
                ", remarks='" + remarks + '\'' +
                ", type=" + type +
                '}';
    }
}
