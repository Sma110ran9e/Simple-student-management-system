/*
 Navicat Premium Data Transfer

 Source Server         : 5
 Source Server Type    : MySQL
 Source Server Version : 50644
 Source Host           : localhost:3306
 Source Schema         : ssmsims

 Target Server Type    : MySQL
 Target Server Version : 50644
 File Encoding         : 65001

 Date: 31/12/2019 16:50:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for newclass
-- ----------------------------
DROP TABLE IF EXISTS `newclass`;
CREATE TABLE `newclass`  (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `teachername` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `teacherid` int(11) DEFAULT NULL,
  `classtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `classplace` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `capacity` int(255) DEFAULT NULL,
  `stuno` int(11) DEFAULT 0,
  `credit` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`classid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 111 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of newclass
-- ----------------------------
INSERT INTO `newclass` VALUES (106, '软工导论2', 'teacher1', 1001, '3-16周 周三13:30-16:05', 'A2-226', 12, 0, '3');
INSERT INTO `newclass` VALUES (107, '计算机组成原理', 'teacher5', 1005, '1-16周 周五9:50-12:15', 'A3-117', 12, 0, '3');
INSERT INTO `newclass` VALUES (110, '数据存储技术', 'teacher1', 1001, '1-16周 周三9:50-12:15', 'A1-409', 30, 0, '3');

SET FOREIGN_KEY_CHECKS = 1;
