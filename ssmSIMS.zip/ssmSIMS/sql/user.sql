/*
 Navicat Premium Data Transfer

 Source Server         : 5
 Source Server Type    : MySQL
 Source Server Version : 50644
 Source Host           : localhost:3306
 Source Schema         : ssmsims

 Target Server Type    : MySQL
 Target Server Version : 50644
 File Encoding         : 65001

 Date: 31/12/2019 16:51:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `schoolid` int(11) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `birthday` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `place` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `idnumber` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '2',
  `departmentname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `evaluationnumber` int(11) DEFAULT 0,
  `pleasednumber` int(11) DEFAULT 0,
  PRIMARY KEY (`schoolid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (100, 'admin', 'admin', NULL, NULL, NULL, NULL, '110', '0', NULL, NULL, NULL);
INSERT INTO `user` VALUES (1001, 'ma', 'teacher1', '男', '2020-01-01', '浙江绍兴', '330621202001011234', '13812345678', '1', '信息与电子工程学院', 0, 0);
INSERT INTO `user` VALUES (1002, 'zhang', 'teacher2', '男', '2020-01-01', '浙江杭州', '330102202001011234', '13712345678', '1', '信息与电子工程学院', 0, 0);
INSERT INTO `user` VALUES (1003, 'cheng', 'teacher3', '男', '2020-01-01', '浙江宁波', '330102202001015678', '13612345678', '1', '信息与电子工程学院', 0, 0);
INSERT INTO `user` VALUES (1004, 'wang', 'teacher4', '女', '2019-12-31', '浙江杭州', '330102201912310000', '13512345678', '1', '信息与电子工程学院', 0, 0);
INSERT INTO `user` VALUES (1005, 'yu', 'teacher5', '男', '2020-01-01', '浙江杭州', '330102202001021357', '13412345678', '1', '信息与电子工程学院', 0, 0);
INSERT INTO `user` VALUES (172001, '1', 'jjl', '男', '2020-01-03', '江苏南通', '330102202001021357', '13579246810', '2', '信息与电子工程学院', NULL, NULL);
INSERT INTO `user` VALUES (172014, '1', 'zhuchaoyi', '男', '1998-09-08', '浙江杭州', '330102199809083011', '12345678910', '2', '信息与电子工程学院', NULL, NULL);
INSERT INTO `user` VALUES (172021, '1', 'xuxin', '男', '1999-03-01', '浙江绍兴', '330621199903016356', '10987654321', '2', '信息与电子工程学院', NULL, NULL);
INSERT INTO `user` VALUES (172026, 'wzj', 'wzj', '男', '1999-04-21', '浙江绍兴', '33062119990421299X', '15356633073', '2', '信息与电子工程学院', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
