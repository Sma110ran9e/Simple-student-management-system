/*
 Navicat Premium Data Transfer

 Source Server         : 5
 Source Server Type    : MySQL
 Source Server Version : 50644
 Source Host           : localhost:3306
 Source Schema         : ssmsims

 Target Server Type    : MySQL
 Target Server Version : 50644
 File Encoding         : 65001

 Date: 31/12/2019 16:50:22
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for classes
-- ----------------------------
DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes`  (
  `classid` int(11) NOT NULL,
  `classname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `studentid` int(11) DEFAULT NULL,
  `grade` int(255) DEFAULT NULL,
  `teacherid` int(11) NOT NULL,
  `stuno` int(255) DEFAULT NULL,
  `capacity` int(255) DEFAULT NULL,
  `classtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `classplace` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `credit` int(255) DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of classes
-- ----------------------------
INSERT INTO `classes` VALUES (101, '软件工程导论', 172026, 90, 1001, 50, 50, '1-16周 周三13:30-16:05', 'A2-222', 3);
INSERT INTO `classes` VALUES (102, '算法分析', 172026, 85, 1002, 50, 50, '1-16周 周三8:00-9:35', 'A1-310', 2);
INSERT INTO `classes` VALUES (103, '数据结构', 172026, 100, 1004, 50, 50, '1-16周 周一13:30-16:05', 'A2-310', 3);
INSERT INTO `classes` VALUES (104, '操作系统', 172026, 80, 1004, 50, 50, '1-16周 周二15:20-16:55', 'A2-222', 3);
INSERT INTO `classes` VALUES (101, '软件工程导论', 172014, 83, 1001, 50, 50, '1-16周 周三13:30-16:05', 'A2-222', 3);
INSERT INTO `classes` VALUES (102, '算法分析', 172021, 100, 1002, 50, 50, '1-16周 周三8:00-9:35', 'A1-310', 2);
INSERT INTO `classes` VALUES (103, '数据结构', 172021, 87, 1004, 50, 50, '1-16周 周一13:30-16:05', 'A2-310', 3);
INSERT INTO `classes` VALUES (104, '操作系统', 172014, 79, 1004, 50, 50, '1-16周 周二15:20-16:55', 'A2-222', 3);
INSERT INTO `classes` VALUES (101, '软件工程导论', 172021, 95, 1001, 50, 50, '1-16周 周三13:30-16:05', 'A2-222', 3);
INSERT INTO `classes` VALUES (102, '算法分析', 172014, 97, 1002, 50, 50, '1-16周 周三8:00-9:35', 'A1-310', 2);
INSERT INTO `classes` VALUES (103, '数据结构', 172014, 85, 1004, 50, 50, '1-16周 周一13:30-16:05', 'A2-310', 3);
INSERT INTO `classes` VALUES (104, '操作系统', 172021, 79, 1004, 50, 50, '1-16周 周二15:20-16:55', 'A2-222', 3);
INSERT INTO `classes` VALUES (105, '计算机网络', 172014, 80, 1002, 50, 50, '1-16周 周五 9:50-12:15', 'A3-117', 3);
INSERT INTO `classes` VALUES (101, '软件工程导论', 172001, 61, 1001, 50, 50, '1-16周 周三13:30-16:05', 'A2-222', 3);
INSERT INTO `classes` VALUES (102, '算法分析', 172001, 72, 1002, 50, 50, '1-16周 周三8:00-9:35', 'A1-310', 2);
INSERT INTO `classes` VALUES (103, '数据结构', 172001, 83, 1004, 50, 50, '1-16周 周一13:30-16:05', 'A2-310', 3);
INSERT INTO `classes` VALUES (104, '操作系统', 172001, 94, 1004, 50, 50, '1-16周 周二15:20-16:55', 'A2-222', 3);
INSERT INTO `classes` VALUES (105, '计算机网络', 172001, 63, 1002, 50, 50, '1-16周 周五 9:50-12:15', 'A3-117', 3);

SET FOREIGN_KEY_CHECKS = 1;
